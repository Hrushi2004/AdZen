// ChangePassword.jsx

import React from 'react';

const ChangePassword = () => {
  return (
    <div>
      <h2>Change Password Page</h2>
      {/* Add your content here */}
    </div>
  );
};

export default ChangePassword;
