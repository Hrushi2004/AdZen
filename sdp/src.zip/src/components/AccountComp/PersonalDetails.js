// PersonalDetails.jsx

import React from 'react';

const PersonalDetails = () => {
  return (
    <div>
      <h2>Personal Details Page</h2>
      {/* Add your content here */}
    </div>
  );
};

export default PersonalDetails;
