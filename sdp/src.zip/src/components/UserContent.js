import React, { useState } from 'react';
import './UserContent.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCog } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import logo from './logo.png';

const generateRandomSize = () => {
  const width = Math.floor(Math.random() * (3 - 1 - 1)) + 1; // Random width between 1 and 3
  const height = Math.floor(Math.random() * (4 - 2 + 1)) +2 ; // Random height between 2 and 4
  return { width, height };
};

const cardsData = [
  { id: 1, title: 'Business Growth Strategies', content: 'Unlock new opportunities and propel your business to new heights. Join our workshop for exclusive insights!', category: 'Business', ...generateRandomSize() },
  { id: 2, title: 'Coding Bootcamp', content: 'Embark on a coding journey with our intensive bootcamp. Learn to code and kickstart your tech career!', category: 'Technology', ...generateRandomSize() },
  { id: 3, title: 'Digital Marketing Pro Tips', content: 'Boost your online presence with expert digital marketing tips. Stay ahead in the digital landscape!', category: 'Marketing', ...generateRandomSize() },
  { id: 4, title: 'Back to School Tech Deals', content: 'Get ready for the school year with incredible tech deals. Laptops, tablets, and more on sale now!', category: 'Technology', ...generateRandomSize() },
  { id: 5, title: 'Creative Design Services', content: 'Transform your brand with our creative design services. From logos to branding, we have got you covered!', category: 'Design', ...generateRandomSize() },
  { id: 6, title: 'Mastering Data Science', content: 'Dive into the world of data science with our comprehensive courses. Analyze, visualize, and interpret data like a pro!', category: 'Technology', ...generateRandomSize() },
  { id: 7, title: 'Office Furniture Extravaganza', content: 'Upgrade your workspace with our stylish and ergonomic office furniture. Productivity meets comfort!', category: 'Office', ...generateRandomSize() },
  { id: 8, title: 'Social Media Success Secrets', content: 'Unlock the secrets of social media success. Learn strategies to engage, grow, and convert!', category: 'Marketing', ...generateRandomSize() },
  { id: 9, title: 'Back to College Fashion Sale', content: 'Revamp your style for the new academic year. Trendy fashion at unbeatable prices!', category: 'Fashion', ...generateRandomSize() },
  { id: 10, title: 'E-commerce Essentials', content: 'Start your online store journey with our e-commerce essentials. Everything you need to succeed!', category: 'Business', ...generateRandomSize() }, 
  { id: 11, title: 'Business Growth Strategies', content: 'Unlock new opportunities and propel your business to new heights. Join our workshop for exclusive insights!', category: 'Business', ...generateRandomSize() },
  { id: 12, title: 'Coding Bootcamp', content: 'Embark on a coding journey with our intensive bootcamp. Learn to code and kickstart your tech career!', category: 'Technology', ...generateRandomSize() },
  { id: 13, title: 'Digital Marketing Pro Tips', content: 'Boost your online presence with expert digital marketing tips. Stay ahead in the digital landscape!', category: 'Marketing', ...generateRandomSize() },
  { id: 14, title: 'Back to School Tech Deals', content: 'Get ready for the school year with incredible tech deals. Laptops, tablets, and more on sale now!', category: 'Technology', ...generateRandomSize() },
  { id: 15, title: 'Creative Design Services', content: 'Transform your brand with our creative design services. From logos to branding, we have got you covered!', category: 'Design', ...generateRandomSize() },
  { id: 16, title: 'Mastering Data Science', content: 'Dive into the world of data science with our comprehensive courses. Analyze, visualize, and interpret data like a pro!', category: 'Technology', ...generateRandomSize() },
  { id: 17, title: 'Office Furniture Extravaganza', content: 'Upgrade your workspace with our stylish and ergonomic office furniture. Productivity meets comfort!', category: 'Office', ...generateRandomSize() },
  { id: 18, title: 'Social Media Success Secrets', content: 'Unlock the secrets of social media success. Learn strategies to engage, grow, and convert!', category: 'Marketing', ...generateRandomSize() },
  { id: 19, title: 'Back to College Fashion Sale', content: 'Revamp your style for the new academic year. Trendy fashion at unbeatable prices!', category: 'Fashion', ...generateRandomSize() },
  { id: 20, title: 'E-commerce Essentials', content: 'Start your online store journey with our e-commerce essentials. Everything you need to succeed!', category: 'Business', ...generateRandomSize() },
  { id: 21, title: 'Business Growth Strategies', content: 'Unlock new opportunities and propel your business to new heights. Join our workshop for exclusive insights!', category: 'Business', ...generateRandomSize() },
  { id: 22, title: 'Coding Bootcamp', content: 'Embark on a coding journey with our intensive bootcamp. Learn to code and kickstart your tech career!', category: 'Technology', ...generateRandomSize() },
  { id: 23, title: 'Digital Marketing Pro Tips', content: 'Boost your online presence with expert digital marketing tips. Stay ahead in the digital landscape!', category: 'Marketing', ...generateRandomSize() },
  { id: 24, title: 'Back to School Tech Deals', content: 'Get ready for the school year with incredible tech deals. Laptops, tablets, and more on sale now!', category: 'Technology', ...generateRandomSize() },
  { id: 25, title: 'Creative Design Services', content: 'Transform your brand with our creative design services. From logos to branding, we have got you covered!', category: 'Design', ...generateRandomSize() },
  { id: 26, title: 'Mastering Data Science', content: 'Dive into the world of data science with our comprehensive courses. Analyze, visualize, and interpret data like a pro!', category: 'Technology', ...generateRandomSize() },
  { id: 27, title: 'Office Furniture Extravaganza', content: 'Upgrade your workspace with our stylish and ergonomic office furniture. Productivity meets comfort!', category: 'Office', ...generateRandomSize() },
  { id: 28, title: 'Social Media Success Secrets', content: 'Unlock the secrets of social media success. Learn strategies to engage, grow, and convert!', category: 'Marketing', ...generateRandomSize() },
  { id: 29, title: 'Back to College Fashion Sale', content: 'Revamp your style for the new academic year. Trendy fashion at unbeatable prices!', category: 'Fashion', ...generateRandomSize() },
  { id: 30, title: 'E-commerce Essentials', content: 'Start your online store journey with our e-commerce essentials. Everything you need to succeed!', category: 'Business', ...generateRandomSize() },
  
  
];
// ... (unchanged code above)

const UserContent = () => {
  const [showSettings, setShowSettings] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState([]);

  const toggleSettings = () => {
    setShowSettings(!showSettings);
  };

  const handleCategoryChange = (category) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter((c) => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  const calculateCardHeight = (content) => {
    
    const minHeightMultiplier = 2;
    const minHeight = content.length * minHeightMultiplier;
    return Math.max(minHeight, 1); // Ensure a minimum height of 2 (adjust as needed)
  };

  const filteredCards = cardsData.filter((card) =>
    selectedCategories.length === 0 || selectedCategories.includes(card.category)
  );

  return (
    <div className={`app-container ${showSettings ? 'settings-open' : ''}`}>
      <div className="top-container">
        <div className="nav-logo">
          <img src={logo} alt="Logo" className="logo-img" />
          <h1 className="logo-title">AdZen</h1>
        </div>
        <div className="settings" onClick={toggleSettings}>
          <div className="icon">
            <FontAwesomeIcon icon={faCog} />
          </div>
          {showSettings && (
            <div className="dropdown">
              <button>
                <Link to="/account" className="logout-link">
                  Account Info
                </Link>
              </button>
              <button>
                <Link to="/signin" className="logout-link">
                  Logout
                </Link>
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="filter-container">
        <h3>Filter by Category</h3>
        <ul>
          {Array.from(new Set(cardsData.map((card) => card.category))).map((category) => (
            <li key={category}>
              <label>
                <input
                  type="checkbox"
                  value={category}
                  checked={selectedCategories.includes(category)}
                  onChange={() => handleCategoryChange(category)}
                />
                {category}
              </label>
            </li>
          ))}
        </ul>
      </div>

      <div className="scrollable-container">
        <div className="cards-container">
          {filteredCards.map((card, index) => (
            <div
              key={card.id}
              className="card"
              style={{
                gridRowEnd: `span ${card.height}`,
                gridColumnEnd: `span ${card.width}`,
                minHeight: `${calculateCardHeight(card.content)}px`,
              }}
            >
              <div className="card-content">
                <h2>{card.title}</h2>
                <p>{card.content}</p>
                <p>
                  <strong>Category:</strong> {card.category}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UserContent;
