import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Signin.css';
import logo from './logo.png';

function Signin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [forgotPassword, setForgotPassword] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();

    const userCredentials = {
      email,
      password,
    };

    try {
      // Simulate successful authentication for demonstration purposes
      // Replace this with actual authentication logic
      const json = { success: true };

      if (json.success) {
        navigate('/user-content'); // Redirect to the user's content page on success
      } else {
        setError('Authentication failed. Please check your credentials.');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('An error occurred during authentication');
    }
  };

  const handleForgotPassword = () => {
    setForgotPassword(true);
    // You may want to navigate to a separate "Forgot Password" page here
  };

  const handleResetPassword = async () => {
    try {
      // Call your server API to handle the forget password logic
      const response = await fetch('/forgot-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        alert('Password reset instructions sent to your email');
        setForgotPassword(false);
      } else {
        setError('Failed to send reset instructions. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('An error occurred during password reset');
    }
  };

  return (
    <div className="signin-container">
      <div className="logo-container">
        <div className="nav-logo">
          <img src={logo} alt="Logo" className="logo-img" />
        </div>
      </div>
      <form onSubmit={handleSubmit} className="signin-form">
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          className="form-input"
          required
        />

        <div className="password-input-container">
          <input
            type={showPassword ? 'text' : 'password'}
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="form-input"
            required
          />
          <span
            className="password-toggle-icon"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? '🔓' : '🔒'}
          </span>
        </div>

        <button type="submit" className="signin-button">
          Log in
        </button>

        <div className="forgot-password-link">
          <span onClick={handleForgotPassword}>Forgot Password?</span>
        </div>

        {forgotPassword && (
          <div>
            <p>Enter your email to reset the password:</p>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <button type="button" onClick={handleResetPassword}>
              Reset Password
            </button>
          </div>
        )}

        {error && <p className="error-message">{error}</p>}
      </form>
    </div>
  );
}

export default Signin;
