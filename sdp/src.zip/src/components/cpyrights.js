import React from 'react';

function cpyrights() {
 
  return (
    <div className="copyrights-container">
      <div className="copyrights-content">
        <pre>Copyright © 2023 AdZen. All rights reserved.

All materials, content, and intellectual property displayed on this website, including but not limited to text, graphics, logos, images, audio clips, digital downloads, data compilations, and software, are the exclusive property of AdZen or its content suppliers and protected by international copyright laws.

You are granted a limited, non-exclusive, and revocable license to access and use the materials on this website for informational and non-commercial purposes only. Any use, reproduction, distribution, or modification of our content without prior written consent from AdZen is strictly prohibited.

AdZen respects the intellectual property rights of others, and we expect our users and visitors to do the same. If you believe that any content on this website infringes your copyright, please contact us immediately.

All trademarks, service marks, and trade names displayed on this website are the property of their respective owners.

The content provided on this website is for informational purposes only and should not be considered as professional advice. AdZen disclaims any liability for actions taken based on the information provided on this website.

For any inquiries or requests regarding the use of our materials or copyright matters, please contact us at hrushikesh2004.k@gmail.com.

Thank you for visiting AdZen.</pre>
      </div>
    </div>
  );
}

export default cpyrights;
