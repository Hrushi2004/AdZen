const express = require("express");
const mongoose = require("mongoose");
const nodemailer = require("nodemailer");

const UserModel = require("./Userschema");
const cors = require("cors");

const app = express();
app.use(express.json());

app.use(cors({
  origin: ["http://localhost:3000"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "OPTIONS,POST,GET,PUT,PATCH,DELETE")
  next()
})

mongoose.connect("mongodb+srv://Hrushikesh:Hemakumari9@cluster0.lp4reap.mongodb.net/SDP?retryWrites=true&w=majority", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const conn = mongoose.connection
if (conn) {
  console.log("Connected to the database successfully.....!")
}

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'adzenservices@gmail.com',
    pass: 'AdZen@123',
  },
});

app.post("/signin", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await UserModel.findOne({ email: email });

    if (!user) {
      return res.json({ success: false, message: "User not found" });
    }

    if (password === user.password) {
      return res.json({ success: true, message: "Valid password" });
    }

    res.json({ success: false, message: "Authentication failed" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

app.post("/forgot-password", async (req, res) => {
  const { email } = req.body;

  try {
    const user = await UserModel.findOne({ email });

    if (!user) {
      return res.json({ success: false, message: "User not found" });
    }

    const mailOptions = {
      from: 'adzenservices@gmail.com',
      to: email,
      subject: 'Password Recovery',
      text: `Your password is: ${user.password}. Please keep it secure.`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Failed to send email" });
      } else {
        console.log('Email sent: ' + info.response);
        res.json({ success: true, message: "Password sent to email" });
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server is started at port ${PORT}`);
});
