const express = require("express")
const mongoose = require("mongoose")

const UserModel = require("./Userschema")

const port = 4000
const Uri = "mongodb+srv://Hrushikesh:Hemakumari9@cluster0.lp4reap.mongodb.net/SDP?retryWrites=true&w=majority";
//const mongoDb = require("./mongoDb")

const app = express()
app.use(express.json())
//mongoDb()

mongoose.connect(Uri,{useNewUrlParser:true})
const conn = mongoose.connection
conn.on("error",console.error.bind(console, "Error while connecting database"))
conn.once("open", function (){
  console.log("Connected to database......")
})

app.use((req,res,next)=>{
  res.setHeader("Access-Control-Allow-Origin","*")
  res.setHeader("Access-Control-Allow-Headers","Content-Type,Autharization")
  res.setHeader("Access-Control-Allow-Methods",
  "OPTIONS,POST,GET,PUT,PATCH,DELETE")
   next()
})

app.get('/', (req, res) => {
    res.send('Hello World!')
  })

app.post('/adduser', async (request,response)=>{
    const User = UserModel(request.body)
    const userData = await UserModel.findOne({email:request.body.email})
    try{
      if(userData){
        return response.json({success:false})
      }
      else{
      User.save()
      response.json(({success:true}))
      }
    }catch(error){
      console.log(error)
      response.status(500).json({success:false})
    }
})

app.get('/users', async(req,res)=>{
  const users = await UserModel.find({})
  try{
    res.send(users)
  }catch(error){
    res.status(500).send(error)
  }
})
app.listen(port, ()=>{
    console.log(`Server is started at ${port}`)
})